# Hello 8: Finalizing the POST method
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    # Displays the input form
    return render_template("index.html")

@app.route("/greet", methods=["POST"])
def greet():
    # request.form.get is used specifically for POST data
    name = request.form.get("name", "world")
    return render_template("greet.html", name=name)