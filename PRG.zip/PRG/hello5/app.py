# Hello 5: Implementing Layout Inheritance
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    # Check if 'name' is in the URL query string
    if "name" in request.args:
        name = request.args["name"]
    else:
        name = "world"
    
    # Pass the variable 'name' to the template
    return render_template("index.html", name=name)