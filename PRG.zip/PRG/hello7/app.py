# Hello 7: Switching to POST for cleaner URLs and security
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

# We add methods=["POST"] to allow data submission
@app.route("/greet", methods=["POST"])
def greet():
    # request.form is used for POST data
    name = request.form.get("name", "world")
    return render_template("greet.html", name=name)