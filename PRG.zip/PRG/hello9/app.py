from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Handle form submission
        name = request.form.get("name", "world")
        return render_template("greet.html", name=name)
    
    # Handle initial page load
    return render_template("index.html")