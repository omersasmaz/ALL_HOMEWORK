from flask import Flask, render_template, request

app = Flask(__name__)

# 1. Source of Truth: Geçerli sporlar listesi
SPORTS = [
    "Basketball",
    "Soccer",
    "Ultimate Frisbee",
    "Swimming"
]

@app.route("/")
def index():
    # 2. Listeyi template'e gönderiyoruz
    return render_template("index.html", sports=SPORTS)

@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name")
    sport = request.form.get("sport")

    # 3. Sunucu taraflı doğrulama (Server-side validation)
    # Sadece ismin varlığını değil, sporun listemizde olup olmadığını da kontrol ediyoruz.
    if not name or sport not in SPORTS:
        return render_template("failure.html")

    return render_template("success.html")