from flask import Flask, render_template, request

app = Flask(__name__)

# Define a list of valid sports to validate against
SPORTS = ["Basketball", "Soccer", "Tennis", "Swimming"]

@app.route("/")
def index():
    return render_template("index.html", sports=SPORTS)

@app.route("/register", methods=["POST"])
def register():
    # Retrieve form data
    name = request.form.get("name")
    sport = request.form.get("sport")

    # Server-side validation
    # Check if name is empty OR the sport isn't in our list
    if not name or sport not in SPORTS:
        return render_template("failure.html")

    return render_template("success.html")