from cs50 import SQL
from flask import Flask, redirect, render_template, request

app = Flask(__name__)

# Veritabanına bağlan (Dosyanın klasörde olduğundan emin ol)
db = SQL("sqlite:///froshims.db")

SPORTS = ["Basketball", "Soccer", "Ultimate Frisbee"]

@app.route("/")
def index():
    return render_template("index.html", sports=SPORTS)

@app.route("/register", methods=["POST"])
def register():
    # Formdan gelen verileri al
    name = request.form.get("name")
    sport = request.form.get("sport")

    # Doğrulama yap
    if not name or sport not in SPORTS:
        return render_template("error.html", message="Invalid submission. Please check your name and sport.")

    # Veritabanına kaydet
    db.execute("INSERT INTO registrants (name, sport) VALUES(?, ?)", name, sport)

    # Listeleme sayfasına yönlendir
    return redirect("/registrants")

@app.route("/registrants")
def registrants():
    # Tüm kayıtları çek
    rows = db.execute("SELECT * FROM registrants")
    return render_template("registrants.html", registrants=rows)