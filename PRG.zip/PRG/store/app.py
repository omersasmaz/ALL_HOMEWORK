from flask import Flask, render_template, request
from cs50 import SQL

app = Flask(__name__)
db = SQL("sqlite:///store.db")

@app.route("/")
def index():
    # Kitapları veritabanından alıyoruz
    books = db.execute("SELECT * FROM books")
    return render_template("development.html", books=books)

@app.route("/cart", methods=["POST"])
def cart():
    # Kitap seçilince ne olacağını buraya yazarız
    # Şimdilik sadece ana sayfaya geri göndersin
    return "Book selected! <a href='/'>Go back</a>"