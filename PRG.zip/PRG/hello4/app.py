# Hello 4: Standardized variable naming
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    # Look for "name" in the URL parameters (e.g., /?name=Gemini)
    if "name" in request.args:
        name = request.args["name"]
    else:
        # Default value if no name is provided
        name = "world"
    
    # Passing 'name' (Python variable) to 'name' (HTML placeholder)
    return render_template("index.html", name=name)