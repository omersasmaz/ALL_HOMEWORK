from cs50 import SQL
from flask import Flask, redirect, render_template, request

app = Flask(__name__)

db = SQL("sqlite:///froshims.db")

SPORTS = ["Basketball", "Soccer", "Ultimate Frisbee"]

@app.route("/")
def index():
    return render_template("index.html", sports=SPORTS)

@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name")
    # ÖNEMLİ: Birden fazla seçim için getlist kullanıyoruz
    sports = request.form.getlist("sport")

    if not name:
        return render_template("error.html", message="Missing name")
    if not sports:
        return render_template("error.html", message="Missing sport")
    
    for sport in sports:
        if sport not in SPORTS:
            return render_template("error.html", message="Invalid sport")
        # Seçilen her spor için veritabanına yeni bir satır ekle
        db.execute("INSERT INTO registrants (name, sport) VALUES(?, ?)", name, sport)

    return redirect("/registrants")

@app.route("/deregister", methods=["POST"])
def deregister():
    id = request.form.get("id")
    if id:
        db.execute("DELETE FROM registrants WHERE id = ?", id)
    return redirect("/registrants")

@app.route("/registrants")
def registrants():
    registrants = db.execute("SELECT * FROM registrants")
    return render_template("registrants.html", registrants=registrants)