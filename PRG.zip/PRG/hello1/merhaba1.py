from flask import Flask

app = Flask(__name__)

@app.route("/")
def index():
    # Returning a full HTML structure as a string
    return (
        '<!DOCTYPE html>'
        '<html lang="en">'
        '<head>'
        '    <title>hello</title>'
        '</head>'
        '<body>'
        '    <h1>hello, world</h1>'
        '    <p>This is the "merhaba 1" file!</p>'
        '</body>'
        '</html>'
    )