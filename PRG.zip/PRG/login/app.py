from flask import Flask, redirect, render_template, request, session
from flask_session import Session

# Uygulama yapılandırması
app = Flask(__name__)

# Session (Oturum) yapılandırması
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route("/")
def index():
    # Session'dan ismi al, yoksa None döner
    return render_template("index.html", name=session.get("name"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # Formdan gelen ismi session'a kaydet
        session["name"] = request.form.get("name")
        return redirect("/")
    # GET isteği gelirse login formunu göster
    return render_template("login.html")

@app.route("/logout")
def logout():
    # Oturumu temizle ve ana sayfaya dön
    session.clear()
    return redirect("/")