# Says hello to a name provided in the URL
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    # URL'de "name" parametresi var mı kontrol et
    # Örn: /?name=Ahmet
    if "name" in request.args:
        name = request.args["name"]
    else:
        name = "world"
    
    # "name" değişkenini HTML'deki "placeholder" kısmına gönderiyoruz
    return render_template("index.html", placeholder=name)