# Hello 6: Two routes - one for the form, one for the greeting
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    # Renders the page with the input form
    return render_template("index.html")

@app.route("/greet")
def greet():
    # Gets the name from the form, defaults to "world"
    name = request.args.get("name", "world")
    return render_template("greet.html", name=name)