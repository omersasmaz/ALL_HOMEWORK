# README - IBU Snake Game Project

### PROJECT INFORMATION
* Developer: Ömer Şaşmaz[cite: 1]
* Student ID: 1008822[cite: 1]
* University: International Balkan University[cite: 1]
* Course: Introduction to Programming[cite: 1]
* Language: Python 3.12[cite: 1]

---

### 1. DESCRIPTION
This is a classic Snake Game developed as a final project for the Introduction to Programming course[cite: 1]. The game features a scoring system, boundary detection, and self-collision logic[cite: 1]. It was built using the Pygame library to demonstrate modular programming and event-driven logic[cite: 1].

### 2. HOW TO INSTALL
Before running the game, you must ensure that Python and the Pygame library are installed[cite: 1].
1. Open your terminal or command prompt[cite: 1].
2. Install the required library by typing:
   pip install pygame[cite: 1]

### 3. HOW TO RUN
1. Navigate to the directory where the file is located[cite: 1].
2. Run the following command:
   python snake_game.py[cite: 1]

### 4. GAME CONTROLS
* Arrow Keys: Move the snake (Up, Down, Left, Right)[cite: 1].
* C Key: Restart the game after a "Game Over"[cite: 1].
* Q Key: Quit the application[cite: 1].

### 5. PROJECT STRUCTURE
* snake_game.py: The main source code containing game logic and rendering[cite: 1].
* Project_Report.docx: Detailed documentation of the development process[cite: 1].

---

NOTE: This project was developed as part of the Civil Engineering curriculum to demonstrate fundamental programming proficiency[cite: 1].